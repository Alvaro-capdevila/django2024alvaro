from django.shortcuts import render
from django.http import HttpResponse
#from .models import clientes 
#from .forms import clientesform




# Create your views here.
def inicio (request):
    return render(request,"paginas_base/inicio.html")